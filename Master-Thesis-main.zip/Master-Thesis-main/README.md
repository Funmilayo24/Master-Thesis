# Master-Thesis
This contains codes and process of creating knowledge graph
